# CALENDRIER PROJET POMPIER

- [x] 15-02-2024 -> 12-03-2024 : Choix du sujet et rédaction du README
- [x] 13-03-2024 -> 20-03-2024 : Recherche scientifique et architecture du code
- [ ] 22-03-2024 -> 07-04-2024 : Algorithme de décision
- [ ] 08-04-2024 -> 30-04-2024 : Algorithme de génération d'environnement
- [ ] 01-05-2024 -> 07-05-2024 : Interface graphique
- [ ] 08-05-2024 -> 20-05-2024 : Tests et préparation du rendu
