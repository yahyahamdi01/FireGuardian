package uparis.diamanthamdi.backend.algo;

/**
 * Represents a node in a graph.
 */
public interface GraphNode {
    String getId();
}
