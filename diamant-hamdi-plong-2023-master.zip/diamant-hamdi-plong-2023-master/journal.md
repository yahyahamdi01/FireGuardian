# 24/04/2024 Degorre

Remarque : problèmes d'algos qui ne terminent pas (raison la plus plausible : exploration exhaustive d'un trop grand nombre de nœuds -> envisager heuristiques pour explorer les nœuds les plus prometteurs en premier)

Fait :

- [X] Ajouter à chaque plan son échelle 
- [X] Permettre aux utilisateurs de choisir l'echelle des cases
		(ex. 1 case = 10m x 10m, 1 case = 1km x 1km)
- [/] Ajouter une fonction pour indiquer les incendies dans les cases  (pas dans le visualiseur encore)
- [/] Implementer un algo the minimisation de chemin dans le prototype en Java

À faire :

- [ ] Ajouter à la GUI des informations sur la generation / parsing du plan
- [ ] Ajouter une fonction pour stocker/ouvrir un plan converti en text / XML / json
- [ ] Permettre indiquer les incendies dans les cases dans le visualiseur
- [ ] Adapter algos en ajoutant heuristiques évitant de parcourir le graphe de façon exhaustive
- [ ] Trouver une façon de charger un TIFF partiellement (ou une façon d'éviter d'être gêné par les limites de mémoire)

# 03/04/2024 Bernardi

DONE
- deux boucles qui lisent une image et transforment chaque pixel en "type de terrain". You implemented shotwell !


TODO
- [ ] Ajouter à chaque plan son échelle 
- [ ] Permettre aux utilisateurs de choisir l'echelle des cases
		(ex. 1 case = 10m x 10m, 1 case = 1km x 1km)
- [ ] Ajouter à la GUI des informations sur la generation / parsing du plan
- [ ] Ajouter une fonction pour stocker/ouvrir un plan converti en text / XML / json
- [ ] Ajouter une fonction pour indiquer les incendies dans les cases
- [ ] Implementer un algo the minimisation de chemin dans le prototype en Java

# 27/03/2023
Suivi par Emmanuel Bigeon

## Fait
- [ ] Generateur aleatoire de carte
- [x] Implémenter lucioles (dans un environment de visualisation)
- [x] Visualiseur pour exécution des algorithmes

## En cours
- [ ] Testabilité à exprimer (commencer par exprimer les métriques)
- [ ] Implémenter lucioles (critere d'arret, strategie de restart?)
- [ ] Visualiseur pour exécution des algorithmes a ameliorer
- [ ] Continuer recherche bibliographique, exploration des références des articles trouvés

## A faire
- [ ] Modélisation du monde réel via viewer.esa.worlcover.org

# 20/03/2023

- [X] Nouveau calendrier à fixer
- [X] Architecture du code du simulateur
- [X] Identification d'algorithme/papiers scientifique traitant le problème (structurellement)

À faire :

- [ ] Testabilité à exprimer (commencer par exprimer les métriques)
- [ ] Implémenter lucioles
- [ ] Visualiseur pour exécution des algorithmes
- [ ] Continuer recherche bibliographique

# 13/03/2023

Nouveau sujet, programme de résolution d'extinction d'incendie

- [ ] Nouveau calendrier à fixer
- [ ] Testabilité à exprimer
- [ ] Architecture du code du simulateur
- [ ] Identification d'algorithme/papiers scientifique traitant le problème (structurellement)

# 01/12/2023

Suivi par Emmanuel Bigeon

## Résumé
- Devis effectués
- Démo du simulateur sur la branche démo.
- Trouvé les bibliothèques pour codage en RUST/Environnement codage

## Taches
- [ ] Coder des exemple d'utilisation d'arduino a tester en rust (utilisation de librairies de composants)
- [ ] Ajouter a votre simulateur les capacité de votre robot
- [ ] Comment changer l'algo d'exploartion de manière simple (c'est a dire minimum de recompilation)
- [ ] Retravailer compréhension/explication de l'algo de génération de labyrinthe.
- [ ] Ajout du plan du robot
- [ ] Investiguer la validité de l'algorithme main gauche dans un labyrinthe à étages
- [ ] Intégrer les étage dans votre simulateur.

# 24/11/2023

TODO

- [x] preparer les devis en PDF
- [ ] detailler comment les tests dans les lab. virtuels vont être realises,
  avec quelle APIs et quels outils.
- [ ] preparer une demo pour expliquer comment executer ces tests virtuels.

# 17/11/2023

TODO
- [x] preparer un devis in ods format
- [x] écrire le squelet de l'agorithme qui trouve la sortie d'un labyrinthe,
- [ ] detailler comment les tests dans les lab. virtuels vont être realisés,
  avec quelle APIs et quels outils,
- [x] clarifier dans le README.md le rôle des points de départ et points d'arrivé.

# 24/11/2023

TODO

- [ ] preparer les devis en PDF
- [ ] detailler comment les tests dans les lab. virtuels vont être realises,
  avec quelle APIs et quels outils.
- [ ] preparer une demo pour expliquer comment executer ces tests virtuels.
- [x] clarifier dans le README.md le rôle des points de départ et points d'arrivé.
