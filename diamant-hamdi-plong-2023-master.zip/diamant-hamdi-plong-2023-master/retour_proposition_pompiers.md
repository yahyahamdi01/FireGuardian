Proposition à compléter.

- il faut justifier l'intérêt du sujet (ancrage dans la réalité) 
  -> est-il possible de trouver des cas d'étude à traiter, adaptés de situations réelles ? (zone urbaine, forestière, montagneuse, ... )
  -> est-ce que les véhicules envisagés correspondent à ce dont les pompiers disposent ? (vérifier leurs caractéristiques)
- testabilité : détaillez. (une piste : trouver des statistiques d'efficacité des interventions des pompiers, et comparer avec la simulation.)
- remarque : le sujet n'est finalement pas spécifique aux robots. Tous les moyens d'interventions, y compris pilotés par des humains, pourraient être optimisés par un tel algorithme.
- envisager au delà de A* (optimisation multi-critères : efficacité/coût/impact environnemental/...; et s'il y a plusieurs feux, plusieurs véhicules sur un incendie ?)